#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{

}

void MinHeap::MinHeapify(int i)
{

}
 
int MinHeap::parent(int i)
{

}
 
int MinHeap::left(int i)
{

}
 
int MinHeap::right(int i)
{

}
 
int MinHeap::extractMin()
{

}
 
void MinHeap::decreaseKey(int i, int new_val)
{

}
 
int MinHeap::getMin()
{

}
 
void MinHeap::deleteKey(int i)
{

}
 
void MinHeap::insertKey(int k)
{

}

int* MinHeap::getHeap()
{
	return harr;
}

#endif