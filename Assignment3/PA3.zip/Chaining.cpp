#ifndef CHAINING_CPP
#define CHAINING_CPP
#include "Chaining.h"
#include "hashfunctions.cpp"

HashC::HashC(int size){
    
}
HashC::~HashC(){

}

unsigned long HashC :: hash(string input){
  return 0;  
}

void HashC::insert(string word){
  return;
}

ListItem<string>* HashC :: lookup(string word){
  return NULL;
}

void HashC :: deleteWord(string word){
  return;
}

#endif